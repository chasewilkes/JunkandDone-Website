JUNK & DONE WEBSITE VERSION 2

CHANGES INCLUDED
Texting is now the preferred contact method for the quickest response.
Calling remains available as a secondary option.
Smaller jobs explain that the final quote will usually be confirmed when Junk & Done arrives for the scheduled removal.
Added land cleaning and outdoor cleanup.
Changed residential wording so the site does not rely on the word homes.
Changed realtor wording to Real Estate Industry Jobs.
Changed the before and after headline to From chaos to cleared.
Removed the Real Junk & Done job photos line.
Changed pricing wording to Straightforward pricing based on trailer space.
Pricing now says access, stairs, carry distance, handling, travel, and job conditions will affect the final quote.
Added a Metro Atlanta service map that highlights Fulton, Forsyth, Cherokee, Cobb, Gwinnett, DeKalb, Hall, and Dawson counties.
Added a Testimonials section without inventing customer reviews.
Removed hyphen style wording from the visible customer facing copy.
The estimate form now prepares a text message instead of an email.

MAP DATA
The map uses OpenStreetMap for the base map and U.S. Census Bureau TIGERweb county boundaries for the highlighted counties.

GITHUB UPDATE
Upload and replace index.html, styles.css, script.js, robots.txt, and sitemap.xml.
Keep the assets folder in the repository.

The form does not upload photos to a server. Customers can attach photos to the text message before sending.

VERSION 3 REVISION
Top navigation button changed from Text for an Estimate to Get an Estimate.
Hero buttons changed from texting/calling actions to Get an Estimate and View Pricing.
Texting remains the preferred contact method within the estimate and contact sections.

VERSION 4 REVISION
Estimate section headline changed from Text us what needs to go. to Tell us what needs to go.

VERSION 5 REVISION
Reworked the entire Get an Estimate section so it focuses on submitting an estimate request rather than texting.
The form button now says Send Estimate Request.
The form now prepares an email request instead of a text message.
Direct call, text, and email options remain available as secondary contact methods.
